/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { logger } from './logger';
import { CURRICULUM_FOCUS_HEADER_BASE, CURRICULUM_FOCUS_PRIMARY_ACTION_HEADER_TEMPLATE, CURRICULUM_FOCUS_SUPPORTING_CONTEXT_HEADER, CURRICULUM_FOCUS_EXECUTION_DIRECTIVE_HEADER, CURRICULUM_FOCUS_EXECUTION_DIRECTIVE_BODY } from "./prompts";
/**
 * Initiates a new consolidation session.
 * This is the entry point into the consolidation loop.
 * @param learnerModel - The current state of the learner.
 * @param teachingPlanForPhase - The full teaching plan for the current phase.
 * @returns A new ConsolidationState object, or null if no remediation is needed.
 */
export function initiateConsolidation(learnerModel, teachingPlanForPhase) {
    const WEAKNESS_THRESHOLD = 0.7; // Points with scores below this are candidates for remediation.
    const MAX_POINTS_TO_REMEDIATE = 4;
    const allPointsWithScores = teachingPlanForPhase
        .flatMap((chunk, chunkIndex) => chunk.map(point => ({
        ...point, // Spread text and kcValue
        chunkIndex,
        // Access understanding_score using point.text as the key
        score: learnerModel.contentPointsCoverage?.[point.text]?.understanding_score ?? WEAKNESS_THRESHOLD,
    })));
    let weakPoints = allPointsWithScores
        .filter(point => point.score < WEAKNESS_THRESHOLD)
        .sort((a, b) => a.score - b.score) // Sort by score to get weakest first
        .slice(0, MAX_POINTS_TO_REMEDIATE);
    if (weakPoints.length === 0 && allPointsWithScores.length > 0) {
        // This can happen if all points are >= 0.7 but the cumulative score is still < 0.65.
        // In this case, we take the up to 4 lowest-scoring points, regardless of threshold.
        const lowestScoringPoints = allPointsWithScores
            .sort((a, b) => a.score - b.score)
            .slice(0, MAX_POINTS_TO_REMEDIATE);
        weakPoints = lowestScoringPoints; // Assign directly
    }
    if (weakPoints.length === 0)
        return null; // No points to remediate.
    // Group the weak points by their original chunk index.
    const plan = new Map();
    for (const point of weakPoints) { // point here includes text, kcValue, chunkIndex, score
        if (!plan.has(point.chunkIndex)) {
            plan.set(point.chunkIndex, []);
        }
        // Construct a TeachingPoint for the plan
        plan.get(point.chunkIndex).push({ text: point.text, kcValue: point.kcValue });
    }
    const planOrder = Array.from(plan.keys()).sort((a, b) => a - b);
    const initialState = {
        stage: 'Diagnosing',
        plan: plan,
        planOrder: planOrder,
        currentPlanStep: 0,
    };
    // Centralized Log Point 1: Initiation
    logger.warn(`[CONSOLIDATION] Initiated. Found ${weakPoints.length} weak points across ${plan.size} chunks.`, {
        plan: Object.fromEntries(plan.entries())
    });
    return initialState;
}
/**
 * Advances the consolidation state to the next stage.
 * @param state - The current consolidation state.
 * @param userInput - The user's last input.
 */
export function advanceConsolidationStage(state, userInput) {
    const oldStage = state.stage;
    switch (state.stage) {
        case 'Diagnosing':
            state.stage = 'Planning';
            state.userDiagnosisResponse = userInput;
            break;
        case 'Planning':
            state.stage = 'Executing';
            break;
        case 'Executing':
            if (state.currentPlanStep < state.planOrder.length - 1) {
                state.currentPlanStep++;
            }
            else {
                // The plan is complete. Loop back to the beginning for re-diagnosis on the next turn.
                // The main curriculum loop will terminate this if mastery is achieved.
                state.stage = 'Diagnosing';
                state.currentPlanStep = 0;
            }
            break;
    }
    // Centralized Log Point 2: Stage Transition
    logger.log(`[CONSOLIDATION] Stage advanced: ${oldStage} -> ${state.stage}`);
}
/**
 * Generates the specific curriculum focus instruction for the current consolidation stage.
 * @param item - The current curriculum item.
 * @param state - The current consolidation state.
 * @returns A string containing the detailed prompt for the Sensei.
 */
export function getConsolidationFocusInstruction(item, state) {
    let primaryActionType = "";
    let primaryActionInstruction = "";
    switch (state.stage) {
        case 'Diagnosing':
            primaryActionType = "Consolidation: Diagnose Weaknesses";
            const allWeakPoints = Array.from(state.plan.values()).flat().map(p => p.text);
            primaryActionInstruction = `You are in a consolidation loop because the learner's overall mastery is not yet sufficient.
1.  **Present a Consolidation Report:** Start by transparently explaining that you want to review a few key concepts to solidify understanding.
2.  **List the Weak Points:** Clearly list the following teaching points that need review:
${allWeakPoints.map(p => `    - "${p}"`).join('\n')}
3.  **Ask Diagnostic Questions:** For EACH of the points listed above, ask 1-2 targeted, open-ended questions to pinpoint the exact source of confusion. Do not provide explanations yet. Your goal is to gather information.`;
            break;
        case 'Planning':
            primaryActionType = "Consolidation: Analyze & Plan Reteaching";
            primaryActionInstruction = `The user has responded to your diagnostic questions.
1.  **Analyze the User's Response:** In your response, first analyze their answers (provided in the chat history: "${state.userDiagnosisResponse}"). Explicitly state what you believe the "laser-focused" weakness is for each topic. For example: "Thanks for explaining. For the 'base case' concept, it seems the core issue is about when it should return 0 vs. 1. For the 'recursive step', the confusion appears to be around how the return values are combined."
2.  **Announce the Reteaching Plan:** After the analysis, present a clear, step-by-step plan for how you will address these points in the upcoming turns.`;
            break;
        case 'Executing':
            const currentChunkIndex = state.planOrder[state.currentPlanStep];
            const pointsToRemediate = state.plan.get(currentChunkIndex); // pointsToRemediate is TeachingPoint[]
            primaryActionType = `Consolidation: Execute Reteaching (Chunk ${currentChunkIndex + 1})`;
            primaryActionInstruction = `You are executing step ${state.currentPlanStep + 1} of the reteaching plan you previously announced.
1.  **State Your Focus:** Begin by saying you are now focusing on the points from Chunk ${currentChunkIndex + 1}.
2.  **Provide Focused Remediation:** Provide a new, detailed, and "laser-focused" explanation for the following specific weak points. Your explanation MUST directly address the weaknesses you diagnosed in the 'Planning' stage. Use new analogies or examples.
${pointsToRemediate.map(p => `    - "${p.text}"`).join('\n')}`; // Access p.text, which is valid for TeachingPoint
            break;
    }
    // This constructs the full prompt structure, similar to the main getCurriculumFocusInstruction function.
    return `${CURRICULUM_FOCUS_HEADER_BASE}
- Current Module: ${item.moduleTitle}
- Current Pedagogical Phase: ${item.isModuleWidePhase ? 'Module-Wide Consolidation' : 'Concept Consolidation'}

${CURRICULUM_FOCUS_PRIMARY_ACTION_HEADER_TEMPLATE(primaryActionType)}
${primaryActionInstruction}

${CURRICULUM_FOCUS_SUPPORTING_CONTEXT_HEADER}
- Module Goal: "${item.moduleGoal}"
${item.concept ? `- Concept: "${item.concept.title}"` : ''}

${CURRICULUM_FOCUS_EXECUTION_DIRECTIVE_HEADER}
${CURRICULUM_FOCUS_EXECUTION_DIRECTIVE_BODY}
]`;
}
