/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { LearnerModel } from "./adaptiveEngine";
import { updateMessageStream } from './ui';
import { MAIN_SENSEI_RESPONSE_SYSTEM_INSTRUCTION_TEMPLATE_FUNCTION } from './prompts';
import { 
    MODULE_INTRODUCTION_CHAT_MODEL_CONFIG,
    MAIN_SENSEI_RESPONSE_CHAT_MODEL_CONFIG
} from './model_usage';
import { logger } from './logger';

/**
 * Streams the introductory module message from Sensei.
 * @param chat - The persistent Chat instance.
 * @param introContext - The dynamic context for the introduction.
 * @param moduleTitleForPrompt - The title of the module to include in the initial message.
 * @param senseiMessageId - The ID of the message bubble to update.
 * @returns A promise that resolves to the full response text.
 * @throws Re-throws errors from the AI call.
 */
export async function streamModuleIntroduction(
    chat: Chat,
    introContext: string,
    moduleTitleForPrompt: string,
    senseiMessageId: string
): Promise<string> {
    let fullResponseText = "";
    
    // Combine context with module start message
    const messageWithContext = `${introContext}

Let's begin ${moduleTitleForPrompt}.`;
    
    // LOG: First LLM prompt after module selection
    logger.warn("🎯 FIRST LLM PROMPT AFTER MODULE SELECTION 🎯");
    logger.warn("===== FULL PROMPT SENT TO LLM (Module Introduction) =====");
    logger.warn(messageWithContext);
    logger.warn("===== END OF MODULE INTRODUCTION PROMPT =====");
    
    const stream = await chat.sendMessageStream({ message: messageWithContext });
    for await (const chunk of stream) {
        const chunkText = chunk.text;
        if (chunkText) {
            fullResponseText += chunkText;
            updateMessageStream(senseiMessageId, fullResponseText);
        }
    }
    return fullResponseText;
}

/**
 * Builds the complete dynamic context for Sensei's turn.
 * @returns The complete dynamic context string.
 */
export function buildSenseiDynamicSystemInstruction(
    curriculumFocusInstruction: string,
    pedagogicalGuidanceDirective: string | undefined
): string {
    let isMustObey = false;
    let proseDirective = pedagogicalGuidanceDirective; // Default to the full string if parsing fails
    let tempDirective = pedagogicalGuidanceDirective || ""; // Use a non-null string for parsing

    // Step 1: Check for and strip the MUST_OBEY prefix.
    if (tempDirective.startsWith('MUST_OBEY ')) {
        isMustObey = true;
        tempDirective = tempDirective.substring('MUST_OBEY '.length);
    }

    // Step 2: Find the first colon to separate the Action_Type from the prose.
    const colonIndex = tempDirective.indexOf(':');
    if (colonIndex !== -1) {
        // The "proseDirective" is the part *after* the first colon.
        proseDirective = tempDirective.substring(colonIndex + 1).trim();
    } else {
        // Fallback: if no colon, use the whole (partially cleaned) string as the prose.
        proseDirective = tempDirective.trim();
    }

    // Step 3: Ensure we don't pass an empty string where undefined is more semantic.
    if (!proseDirective) {
        proseDirective = undefined;
    }

    return MAIN_SENSEI_RESPONSE_SYSTEM_INSTRUCTION_TEMPLATE_FUNCTION(
        curriculumFocusInstruction,
        proseDirective,
        isMustObey
    );
}

/**
 * Streams the main Sensei response to the user's input.
 * @param chat - The persistent Chat instance.
 * @param dynamicContext - The dynamic context for this turn.
 * @param currentUserInput - The user's current message text.
 * @param senseiMessageId - The ID of the message bubble to update.
 * @returns A promise that resolves to the full response text.
 * @throws Re-throws errors from the AI call.
 */
export async function streamMainSenseiResponse(
    chat: Chat,
    dynamicContext: string,
    currentUserInput: string,
    senseiMessageId: string
): Promise<string> {
    let fullResponseText = "";
    
    // Combine context with user input in the message
    const messageWithContext = `${dynamicContext}

User: ${currentUserInput}`;
    
    // LOG: Subsequent teaching prompts
    logger.warn("📚 SUBSEQUENT TEACHING PROMPT 📚");
    logger.warn("===== FULL PROMPT SENT TO LLM (Main Teaching Response) =====");
    logger.warn(messageWithContext);
    logger.warn("===== END OF MAIN TEACHING PROMPT =====");
    
    const stream = await chat.sendMessageStream({ message: messageWithContext });
    
    for await (const chunk of stream) { // chunk type is GenerateContentResponse
        const chunkText = chunk.text;
        if (chunkText) {
            fullResponseText += chunkText;
            updateMessageStream(senseiMessageId, fullResponseText);
        }
    }
    return fullResponseText;
}