#!/usr/bin/env python3
"""
Module Structure Analyzer for Modules.txt
Analyzes module boundaries, section patterns, and line counts
"""

import re

def analyze_modules(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    modules = []
    current_module = None
    current_section = None
    line_num = 0
    
    # Pattern to identify module headers
    module_pattern = re.compile(r'^Module\s+[\d.]+:', re.IGNORECASE)
    
    # Pattern to identify main sections (looking for sections that start with a keyword followed by colon)
    section_patterns = {
        'goal': re.compile(r'^Goal:', re.IGNORECASE),
        'preamble': re.compile(r'^Preamble:', re.IGNORECASE),
        'prerequisites': re.compile(r'^Prerequisites:', re.IGNORECASE),
        'concepts': re.compile(r'^Concepts:', re.IGNORECASE),
        'methodology': re.compile(r'^Methodology:', re.IGNORECASE)
    }
    
    for i, line in enumerate(lines):
        line = line.strip()
        line_num = i + 1
        
        # Check if this is a module header
        if module_pattern.match(line):
            # Save previous module if exists
            if current_module:
                modules.append(current_module)
            
            # Start new module
            current_module = {
                'title': line,
                'start_line': line_num,
                'sections': [],
                'total_lines': 0
            }
            current_section = None
            continue
        
        # Check if this is a section header
        section_found = False
        for section_name, pattern in section_patterns.items():
            if pattern.match(line):
                # Save previous section if exists
                if current_section and current_module:
                    current_section['line_count'] = line_num - current_section['start_line'] - 1
                    current_module['sections'].append(current_section)
                
                # Start new section
                current_section = {
                    'name': section_name,
                    'start_line': line_num,
                    'line_count': 0
                }
                section_found = True
                break
        
        if section_found:
            continue
    
    # Handle the last module and section
    if current_section and current_module:
        current_section['line_count'] = len(lines) - current_section['start_line']
        current_module['sections'].append(current_section)
    
    if current_module:
        modules.append(current_module)
    
    # Calculate total lines for each module
    for i, module in enumerate(modules):
        if i < len(modules) - 1:
            module['total_lines'] = modules[i + 1]['start_line'] - module['start_line'] - 1
        else:
            module['total_lines'] = len(lines) - module['start_line'] + 1
    
    return modules

def analyze_subsections(file_path):
    """Analyze methodology subsections for socratic, solidify, verify patterns"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Look for patterns in methodology sections
    socratic_pattern = re.compile(r'Socratic\s+(?:Exploration|Tracing)', re.IGNORECASE)
    solidify_pattern = re.compile(r'Solidify\s*(?:&\s*(?:Prepare|Conclude))?', re.IGNORECASE)
    verify_pattern = re.compile(r'Verify\s*(?:&\s*Solidify)?', re.IGNORECASE)
    
    socratic_matches = len(socratic_pattern.findall(content))
    solidify_matches = len(solidify_pattern.findall(content))
    verify_matches = len(verify_pattern.findall(content))
    
    return {
        'socratic_occurrences': socratic_matches,
        'solidify_occurrences': solidify_matches,
        'verify_occurrences': verify_matches
    }

def print_analysis(modules, subsection_info):
    print("=" * 80)
    print("MODULES.TXT STRUCTURE ANALYSIS")
    print("=" * 80)
    
    print(f"\nTOTAL MODULES: {len(modules)}")
    print("\nMODULE SUMMARY:")
    print("-" * 50)
    
    for i, module in enumerate(modules, 1):
        print(f"{i}. {module['title']}")
        print(f"   Lines: {module['start_line']}-{module['start_line'] + module['total_lines'] - 1} ({module['total_lines']} total)")
        
        section_summary = []
        for section in module['sections']:
            section_summary.append(f"{section['name']}({section['line_count']})")
        
        if section_summary:
            print(f"   Sections: {', '.join(section_summary)}")
        print()
    
    print("\nDETAILED SECTION ANALYSIS:")
    print("-" * 50)
    
    # Create a comprehensive table
    print(f"{'Module':<40} {'Goal/Preamble':<12} {'Concepts':<10} {'Methodology':<12} {'Total':<8}")
    print("-" * 82)
    
    for module in modules:
        sections_dict = {section['name']: section['line_count'] for section in module['sections']}
        
        goal_lines = sections_dict.get('goal', 0) + sections_dict.get('preamble', 0) + sections_dict.get('prerequisites', 0)
        concepts_lines = sections_dict.get('concepts', 0)
        methodology_lines = sections_dict.get('methodology', 0)
        
        # Truncate module title if too long
        title = module['title'][:38] + ".." if len(module['title']) > 40 else module['title']
        
        print(f"{title:<40} {goal_lines:<12} {concepts_lines:<10} {methodology_lines:<12} {module['total_lines']:<8}")
    
    print(f"\nSUBSECTION PATTERNS WITHIN METHODOLOGY:")
    print(f"- 'Socratic Exploration/Tracing' found: {subsection_info['socratic_occurrences']} times")
    print(f"- 'Solidify' found: {subsection_info['solidify_occurrences']} times") 
    print(f"- 'Verify' found: {subsection_info['verify_occurrences']} times")
    
    print(f"\nSTRUCTURE PATTERNS IDENTIFIED:")
    print("- Modules follow consistent naming: 'Module X: Title (Version Y)'")
    print("- Some modules have decimal numbers (1.5, 6.5)")
    print("- Main sections are: Goal/Preamble, Prerequisites, Concepts, Methodology")
    print("- Socratic, Solidify, and Verify are typically embedded as numbered items within Methodology")
    print("- Section headers use format: 'SectionName:' (colon after section name)")
    print("- Content is heavily indented with tabs and numbered/bulleted lists")

if __name__ == "__main__":
    file_path = "/Users/aligunes/Documents/sensei_files_20250615_204052/Modules.txt"
    
    try:
        modules = analyze_modules(file_path)
        subsection_info = analyze_subsections(file_path)
        print_analysis(modules, subsection_info)
    except FileNotFoundError:
        print(f"Error: Could not find file {file_path}")
    except Exception as e:
        print(f"Error analyzing file: {e}")