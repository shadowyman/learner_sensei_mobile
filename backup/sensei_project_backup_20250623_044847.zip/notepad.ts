/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { logger } from './logger';
import { marked } from 'marked';
import { Curriculum } from './curriculum';

interface Note {
    id: string;
    moduleTitle: string;
    conceptTitle: string;
    conceptIndex: number;
    moduleIndex: number;
    text: string;
    timestamp: Date;
}

interface NotepadState {
    notes: Note[];
    isOpen: boolean;
}

export class Notepad {
    private state: NotepadState = {
        notes: [],
        isOpen: false
    };
    
    private modalElement: HTMLDivElement | null = null;
    private notepadButton: HTMLButtonElement | null = null;
    private curriculum: Curriculum | null = null;
    private currentActiveConceptIndex: number | null = null;
    private currentModuleIndex: number | null = null;
    
    constructor() {
        logger.info('Notepad module initialized');
    }
    
    public initialize(curriculum: Curriculum): void {
        this.curriculum = curriculum;
        this.createModal();
        this.attachEventListeners();
        logger.info('Notepad modal created and attached to DOM');
    }
    
    public updateActiveConceptIndex(index: number | null): void {
        this.currentActiveConceptIndex = index;
    }
    
    public updateActiveModuleIndex(moduleIndex: number | null): void {
        this.currentModuleIndex = moduleIndex;
    }
    
    public addNote(selectedText: string, markdownText: string): void {
        if (this.currentActiveConceptIndex === null || this.currentModuleIndex === null || !this.curriculum) {
            logger.warn('Cannot add note: no active concept or module');
            return;
        }
        
        const module = this.curriculum.modules[this.currentModuleIndex];
        
        if (!module || !module.concepts[this.currentActiveConceptIndex]) {
            logger.warn('Cannot add note: concept not found in current module');
            return;
        }
        
        const concept = module.concepts[this.currentActiveConceptIndex];
        const note: Note = {
            id: `note-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            moduleTitle: module.title,
            conceptTitle: concept.title,
            conceptIndex: this.currentActiveConceptIndex,
            moduleIndex: this.currentModuleIndex,
            text: markdownText,
            timestamp: new Date()
        };
        
        this.state.notes.push(note);
        logger.info('Note added to concept:', concept.title);
        logger.info('Total notes in notepad:', this.state.notes.length);
        
        if (this.state.isOpen) {
            this.renderNotes();
        }
    }
    
    private createModal(): void {
        this.modalElement = document.createElement('div');
        this.modalElement.id = 'notepad-modal';
        this.modalElement.className = 'notepad-modal';
        this.modalElement.style.display = 'none';
        
        this.modalElement.innerHTML = `
            <div class="notepad-modal-content">
                <div class="notepad-modal-header">
                    <h2 class="notepad-modal-title">📓 My Notes</h2>
                    <button class="notepad-modal-close" aria-label="Close notepad">&times;</button>
                </div>
                <div class="notepad-modal-body">
                    <div id="notepad-notes-container"></div>
                </div>
            </div>
        `;
        
        document.body.appendChild(this.modalElement);
    }
    
    private attachEventListeners(): void {
        this.notepadButton = document.getElementById('notepad-button') as HTMLButtonElement;
        if (this.notepadButton) {
            this.notepadButton.addEventListener('click', () => this.toggleModal());
        }
        
        const closeButton = this.modalElement?.querySelector('.notepad-modal-close');
        if (closeButton) {
            closeButton.addEventListener('click', () => this.closeModal());
        }
        
        this.modalElement?.addEventListener('click', (e) => {
            if (e.target === this.modalElement) {
                this.closeModal();
            }
        });
    }
    
    private toggleModal(): void {
        if (this.state.isOpen) {
            this.closeModal();
        } else {
            this.openModal();
        }
    }
    
    private openModal(): void {
        if (!this.modalElement) return;
        
        this.state.isOpen = true;
        this.modalElement.style.display = 'flex';
        this.renderNotes();
        logger.info('Notepad opened');
    }
    
    private closeModal(): void {
        if (!this.modalElement) return;
        
        this.state.isOpen = false;
        this.modalElement.style.display = 'none';
        logger.info('Notepad closed');
    }
    
    private renderNotes(): void {
        const container = document.getElementById('notepad-notes-container');
        if (!container) return;
        
        if (this.state.notes.length === 0) {
            container.innerHTML = '<p class="notepad-empty-message">No notes yet. Select text and click "Add to Notepad" to save notes.</p>';
            return;
        }
        
        // Group notes by module index first
        const notesByModule = new Map<number, Map<number, Note[]>>();
        this.state.notes.forEach(note => {
            if (!notesByModule.has(note.moduleIndex)) {
                notesByModule.set(note.moduleIndex, new Map<number, Note[]>());
            }
            const moduleNotes = notesByModule.get(note.moduleIndex)!;
            
            if (!moduleNotes.has(note.conceptIndex)) {
                moduleNotes.set(note.conceptIndex, []);
            }
            moduleNotes.get(note.conceptIndex)!.push(note);
        });
        
        let html = '';
        notesByModule.forEach((conceptsMap, moduleIndex) => {
            // Get module title from the first note
            const firstNote = conceptsMap.values().next().value[0];
            const moduleTitle = firstNote.moduleTitle;
            
            html += `<div class="notepad-module-section">
                <h2 class="notepad-module-header">Module: ${moduleTitle}</h2>`;
            
            conceptsMap.forEach((notes, conceptIndex) => {
                const conceptTitle = notes[0].conceptTitle;
                html += `<div class="notepad-concept-section">
                    <h3 class="notepad-concept-header">${conceptTitle}</h3>
                    <div class="notepad-notes-list">`;
                
                notes.forEach((note, index) => {
                    if (index > 0) {
                        html += '<hr class="notepad-note-separator">';
                    }
                    html += this.createNoteCard(note);
                });
                
                html += '</div></div>';
            });
            
            html += '</div>';
        });
        
        container.innerHTML = html;
        this.attachNoteEventListeners();
    }
    
    private createNoteCard(note: Note): string {
        const renderedContent = marked(note.text);
        return `
            <div class="notepad-note-card" data-note-id="${note.id}">
                <div class="notepad-note-content" contenteditable="false">
                    ${renderedContent}
                </div>
                <div class="notepad-note-actions">
                    <button class="notepad-note-edit" title="Edit note">✏️</button>
                    <button class="notepad-note-delete" title="Delete note">🗑️</button>
                </div>
            </div>
        `;
    }
    
    private attachNoteEventListeners(): void {
        const editButtons = this.modalElement?.querySelectorAll('.notepad-note-edit');
        const deleteButtons = this.modalElement?.querySelectorAll('.notepad-note-delete');
        
        editButtons?.forEach(button => {
            button.addEventListener('click', (e) => {
                const card = (e.target as HTMLElement).closest('.notepad-note-card');
                if (card) {
                    this.toggleEditMode(card as HTMLElement);
                }
            });
        });
        
        deleteButtons?.forEach(button => {
            button.addEventListener('click', (e) => {
                const card = (e.target as HTMLElement).closest('.notepad-note-card');
                const noteId = card?.getAttribute('data-note-id');
                if (noteId) {
                    this.deleteNote(noteId);
                }
            });
        });
    }
    
    private toggleEditMode(card: HTMLElement): void {
        const content = card.querySelector('.notepad-note-content') as HTMLElement;
        const editButton = card.querySelector('.notepad-note-edit') as HTMLButtonElement;
        const noteId = card.getAttribute('data-note-id');
        
        if (!content || !noteId) return;
        
        const isEditing = content.contentEditable === 'true';
        
        if (isEditing) {
            content.contentEditable = 'false';
            editButton.textContent = '✏️';
            
            const note = this.state.notes.find(n => n.id === noteId);
            if (note) {
                note.text = content.innerText;
                logger.info('Note edited, ID:', noteId);
            }
            
            const renderedContent = marked(content.innerText);
            content.innerHTML = renderedContent;
        } else {
            const note = this.state.notes.find(n => n.id === noteId);
            if (note) {
                content.contentEditable = 'true';
                content.innerText = note.text;
                editButton.textContent = '💾';
                content.focus();
            }
        }
    }
    
    private deleteNote(noteId: string): void {
        const index = this.state.notes.findIndex(n => n.id === noteId);
        if (index !== -1) {
            this.state.notes.splice(index, 1);
            logger.info('Note deleted, ID:', noteId);
            this.renderNotes();
        }
    }
}

export const notepad = new Notepad();