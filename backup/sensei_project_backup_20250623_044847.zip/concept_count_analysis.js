const fs = require('fs');

// Read the Modules.txt file
const txt = fs.readFileSync('/Users/aligunes/Documents/sensei_files_20250615_204052/Modules.txt', 'utf8');

// Current regexes from curriculum.ts
const moduleRegex = /Module (\d+(?:\.\d+)?):\s*(.*?)\n[\s\S]*?Goal:\s*([\s\S]*?)\nConcepts[\s\S]*?:\s*([\s\S]*?)(?=\nMethodology:|\nModule|$)/gi;
// Updated regex to handle varying indentation
const conceptRegex = /(?:^|\n)\s*(\d+)\.\s+([^:]+?):\s*([\s\S]*?)(?=\n\s*\d+\.\s+[^:]+:|\nMethodology:|$)/g;

console.log("=== CONCEPT COUNT ANALYSIS ===\n");

let moduleMatch;
let totalConcepts = 0;
const results = [];

while ((moduleMatch = moduleRegex.exec(txt)) !== null) {
    const moduleId = moduleMatch[1];
    const moduleTitle = moduleMatch[2].trim();
    const conceptsSection = moduleMatch[4];
    
    // Count concepts in this module
    let conceptMatch;
    let conceptCount = 0;
    conceptRegex.lastIndex = 0; // Reset regex
    
    while ((conceptMatch = conceptRegex.exec(conceptsSection)) !== null) {
        conceptCount++;
    }
    
    results.push({
        id: moduleId,
        title: moduleTitle,
        conceptCount: conceptCount
    });
    
    totalConcepts += conceptCount;
}

// Display table
console.log("┌─────────────┬───────────────────────────────────────────────────────┬───────────────┐");
console.log("│ Module ID   │ Module Title                                          │ Concepts      │");
console.log("├─────────────┼───────────────────────────────────────────────────────┼───────────────┤");

results.forEach(module => {
    const truncatedTitle = module.title.length > 53 ? module.title.substring(0, 50) + "..." : module.title;
    const paddedId = module.id.padEnd(11);
    const paddedTitle = truncatedTitle.padEnd(53);
    const paddedCount = module.conceptCount.toString().padStart(13);
    
    console.log(`│ ${paddedId} │ ${paddedTitle} │${paddedCount} │`);
});

console.log("├─────────────┼───────────────────────────────────────────────────────┼───────────────┤");
const paddedTotal = totalConcepts.toString().padStart(13);
console.log(`│ TOTAL       │                                                       │${paddedTotal} │`);
console.log("└─────────────┴───────────────────────────────────────────────────────┴───────────────┘");

console.log(`\nTotal modules found: ${results.length}`);
console.log(`Total concepts extracted: ${totalConcepts}`);

// Show modules with 0 concepts
const zeroConceptModules = results.filter(m => m.conceptCount === 0);
if (zeroConceptModules.length > 0) {
    console.log("\n⚠️  MODULES WITH 0 CONCEPTS:");
    zeroConceptModules.forEach(module => {
        console.log(`   - Module ${module.id}: ${module.title}`);
    });
}