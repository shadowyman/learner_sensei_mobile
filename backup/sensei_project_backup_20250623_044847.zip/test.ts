/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { logger } from './logger';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { parseModulesTxt, Module, generateTeachingPlanForPhase, CurriculumItem } from './curriculum';
import { ARCHETYPE_COMPARISON_TEST_CONFIG } from './model_usage';

// Test Suite Configuration - ENABLED FOR TESTING
const TEST_SUITE_CONFIG = {
    enabled: true, // Set to true to enable test execution
    runArchetypeTest: false, // Set to true to run archetype comparison test
    runConceptExtractionTest: false, // Set to true to run concept extraction test
    runSocraticPhaseInvestigation: true // Set to true to run Socratic phase investigation
};

interface ConceptTestResult {
    conceptId: string;
    conceptTitle: string;
    prompt1Response: string;
    prompt2Response: string;
    match: boolean;
    discrepancy?: string;
}

/**
 * Archetype Comparison Test
 * Tests consistency of archetype classification between two different prompts
 * for concepts from modules M1.5 through M5
 */
export class ArchetypeComparisonTest {
    private genAI: GoogleGenerativeAI;
    private testResults: ConceptTestResult[] = [];
    private prompt1Template: string = '';
    private prompt2Template: string = '';

    constructor(apiKey: string) {
        this.genAI = new GoogleGenerativeAI(apiKey);
    }

    /**
     * Main test execution function
     */
    public async runTest(): Promise<void> {
        logger.warn("🚀 ========== ARCHETYPE COMPARISON TEST STARTING ==========");
        
        try {
            // Load prompt templates
            await this.loadPromptTemplates();
            
            // Extract concepts from modules M1.5-M5
            const concepts = await this.extractConcepts();
            logger.warn(`📊 Found ${concepts.length} concepts to test from modules M1.5-M5`);
            
            // Test each concept
            for (const concept of concepts) {
                await this.testConcept(concept);
            }
            
            // Generate and log final report
            this.generateFinalReport();
            
        } catch (error) {
            logger.error("❌ Test failed with error:", error);
        }
        
        logger.warn("🏁 ========== ARCHETYPE COMPARISON TEST COMPLETED ==========");
    }

    /**
     * Load prompt templates from files
     */
    private async loadPromptTemplates(): Promise<void> {
        logger.warn("📄 Loading prompt templates...");
        
        try {
            // Read testPrompt1.txt
            const prompt1Response = await fetch('./testPrompt1.txt');
            this.prompt1Template = await prompt1Response.text();
            logger.warn("✅ Loaded testPrompt1.txt");
            
            // Read testPrompt2.txt  
            const prompt2Response = await fetch('./testPrompt2.txt');
            this.prompt2Template = await prompt2Response.text();
            logger.warn("✅ Loaded testPrompt2.txt");
            
        } catch (error) {
            throw new Error(`Failed to load prompt templates: ${error}`);
        }
    }

    /**
     * Extract concepts from modules M1.5-M5 using existing curriculum parsing logic
     */
    private async extractConcepts(): Promise<Array<{id: string, title: string, text: string}>> {
        logger.warn("📚 Extracting concepts from modules.txt...");
        
        try {
            // Read modules.txt
            const modulesResponse = await fetch('./Modules.txt');
            const modulesContent = await modulesResponse.text();
            const curriculum = parseModulesTxt(modulesContent);
            
            const concepts: Array<{id: string, title: string, text: string}> = [];
            
            // Find modules M1.5 through M5
            const targetModuleIds = ['Module1_5', 'Module2', 'Module3', 'Module4', 'Module5'];
            
            for (const [moduleIndex, module] of curriculum.modules.entries()) {
                // Check if this module is in our target range
                if (targetModuleIds.includes(module.id)) {
                    // Convert module ID for display (Module1_5 -> M1.5)
                    const displayModuleId = module.id.replace('Module', 'M').replace('_', '.');
                    logger.warn(`📖 Processing ${displayModuleId}: ${module.title}`);
                    
                    // Extract concepts from this module
                    if (module.concepts && module.concepts.length > 0) {
                        for (const [conceptIndex, concept] of module.concepts.entries()) {
                            const conceptId = `${displayModuleId}.${conceptIndex + 1}`;
                            concepts.push({
                                id: conceptId,
                                title: concept.title,
                                text: `${concept.title}\n${concept.text}`
                            });
                        }
                    }
                }
            }
            
            return concepts;
            
        } catch (error) {
            throw new Error(`Failed to extract concepts: ${error}`);
        }
    }

    /**
     * Test a single concept with both prompts
     */
    private async testConcept(concept: {id: string, title: string, text: string}): Promise<void> {
        logger.warn(`\n🧪 Testing Concept ${concept.id}: ${concept.title}`);
        
        try {
            // Prepare prompts by replacing placeholder with actual concept text
            const prompt1 = this.prompt1Template.replace(
                '<REPLACE WITH ACTUAL INDIVIDUAL FULL CONCEPT TEXT HERE>',
                concept.text
            );
            
            const prompt2 = this.prompt2Template.replace(
                '<REPLACE WITH ACTUAL INDIVIDUAL FULL CONCEPT TEXT HERE>',
                concept.text
            );
            
            // Get LLM response for prompt 1
            logger.warn(`📤 Sending concept to LLM with Prompt 1...`);
            const model1 = this.genAI.getGenerativeModel({ 
                model: ARCHETYPE_COMPARISON_TEST_CONFIG.modelName,
                ...ARCHETYPE_COMPARISON_TEST_CONFIG.config
            });
            const result1 = await model1.generateContent(prompt1);
            const response1 = result1.response.text().trim();
            logger.warn(`📥 Prompt 1 Response Received: ${response1}`);
            
            // Get LLM response for prompt 2
            logger.warn(`📤 Sending concept to LLM with Prompt 2...`);
            const model2 = this.genAI.getGenerativeModel({ 
                model: ARCHETYPE_COMPARISON_TEST_CONFIG.modelName,
                ...ARCHETYPE_COMPARISON_TEST_CONFIG.config
            });
            const result2 = await model2.generateContent(prompt2);
            const response2 = result2.response.text().trim();
            logger.warn(`📥 Prompt 2 Response Received: ${response2}`);
            
            // Extract archetype from responses (handle variations in response format)
            const archetype1 = this.extractArchetype(response1);
            const archetype2 = this.extractArchetype(response2);
            
            // Compare results
            const match = archetype1 === archetype2;
            const discrepancy = match ? undefined : `Prompt1: ${archetype1}, Prompt2: ${archetype2}`;
            
            // Store result
            const testResult: ConceptTestResult = {
                conceptId: concept.id,
                conceptTitle: concept.title,
                prompt1Response: archetype1,
                prompt2Response: archetype2,
                match,
                discrepancy
            };
            
            this.testResults.push(testResult);
            
            // Log consolidated result for this concept
            logger.warn(`
📊 ===== CONCEPT ${concept.id} TEST RESULT =====
📌 Concept: ${concept.title}
📝 Full Text: ${concept.text.substring(0, 200)}...
🔵 Prompt 1 Archetype: ${archetype1}
🔵 Prompt 2 Archetype: ${archetype2}
✅ Match: ${match ? 'PASS' : 'FAIL'}
${discrepancy ? `❌ Discrepancy: ${discrepancy}` : ''}
==========================================
            `);
            
        } catch (error) {
            logger.error(`❌ Failed to test concept ${concept.id}: ${error}`);
            this.testResults.push({
                conceptId: concept.id,
                conceptTitle: concept.title,
                prompt1Response: 'ERROR',
                prompt2Response: 'ERROR',
                match: false,
                discrepancy: `Error: ${error}`
            });
        }
    }

    /**
     * Extract archetype from LLM response
     */
    private extractArchetype(response: string): string {
        // List of valid archetypes to look for
        const archetypes = [
            'Foundational Concept',
            'Pattern Definition',
            'Component Deep-Dive',
            'Toolbox/Mechanism',
            'Strategic Heuristic',
            'Synthesis/Application'
        ];
        
        // Clean response and look for archetype
        const cleanResponse = response.replace(/[*`]/g, '').trim();
        
        for (const archetype of archetypes) {
            if (cleanResponse.includes(archetype)) {
                return archetype;
            }
        }
        
        // If no exact match found, return the cleaned response
        return cleanResponse;
    }

    /**
     * Generate and log final report
     */
    private generateFinalReport(): void {
        logger.warn(`
        
🎯 ========== FINAL ARCHETYPE COMPARISON REPORT ==========
        `);
        
        let passCount = 0;
        let failCount = 0;
        const reportLines: string[] = [];
        
        for (const result of this.testResults) {
            if (result.match) {
                passCount++;
                reportLines.push(`${result.conceptId}->Pass`);
            } else {
                failCount++;
                reportLines.push(`${result.conceptId}->Fail [${result.discrepancy}]`);
            }
        }
        
        logger.warn(`📊 Summary: ${passCount} PASSED, ${failCount} FAILED out of ${this.testResults.length} concepts`);
        logger.warn(`\n📋 Detailed Results:\n${reportLines.join(', ')}`);
        
        // Log any failed concepts with details
        if (failCount > 0) {
            logger.warn(`\n❌ Failed Concepts Details:`);
            for (const result of this.testResults) {
                if (!result.match) {
                    logger.warn(`
Concept ${result.conceptId}: ${result.conceptTitle}
- Prompt 1: ${result.prompt1Response}
- Prompt 2: ${result.prompt2Response}
                    `);
                }
            }
        }
        
        logger.warn(`
========================================================
        `);
    }
}

/**
 * Concept Extraction Test
 * Tests and displays the concept extraction functionality
 * Shows individual concepts extracted from all modules
 */
export class ConceptExtractionTest {
    
    constructor() {
        // No API key needed for this test
    }

    /**
     * Main test execution function
     */
    public async runTest(): Promise<void> {
        logger.warn("🚀 ========== CONCEPT EXTRACTION TEST STARTING ==========");
        
        try {
            // Extract concepts from all modules
            const concepts = await this.extractAllConcepts();
            logger.warn(`📊 Found ${concepts.length} total concepts across all modules`);
            
            // Display each concept
            for (const concept of concepts) {
                this.displayConcept(concept);
            }
            
            // Generate summary report
            this.generateSummaryReport(concepts);
            
        } catch (error) {
            logger.error("❌ Concept extraction test failed with error:", error);
        }
        
        logger.warn("🏁 ========== CONCEPT EXTRACTION TEST COMPLETED ==========");
    }

    /**
     * Extract concepts from all modules using existing curriculum parsing logic
     */
    private async extractAllConcepts(): Promise<Array<{id: string, moduleId: string, title: string, text: string}>> {
        logger.warn("📚 Extracting concepts from modules.txt...");
        
        try {
            // Read modules.txt
            const modulesResponse = await fetch('./Modules.txt');
            const modulesContent = await modulesResponse.text();
            const curriculum = parseModulesTxt(modulesContent);
            
            const concepts: Array<{id: string, moduleId: string, title: string, text: string}> = [];
            
            // Extract concepts from all modules
            for (const [moduleIndex, module] of curriculum.modules.entries()) {
                // Convert module ID for display (Module1_5 -> M1.5)
                const displayModuleId = module.id.replace('Module', 'M').replace('_', '.');
                logger.warn(`📖 Processing ${displayModuleId}: ${module.title}`);
                
                // Extract concepts from this module
                if (module.concepts && module.concepts.length > 0) {
                    for (const [conceptIndex, concept] of module.concepts.entries()) {
                        const conceptId = `${displayModuleId}.${conceptIndex + 1}`;
                        concepts.push({
                            id: conceptId,
                            moduleId: displayModuleId,
                            title: concept.title,
                            text: concept.text
                        });
                    }
                } else {
                    logger.warn(`⚠️  Module ${displayModuleId} has no concepts`);
                }
            }
            
            return concepts;
            
        } catch (error) {
            throw new Error(`Failed to extract concepts: ${error}`);
        }
    }

    /**
     * Display a single concept with detailed formatting
     */
    private displayConcept(concept: {id: string, moduleId: string, title: string, text: string}): void {
        logger.warn(`
🧩 ===== CONCEPT ${concept.id} DETAILS =====
📌 Module: ${concept.moduleId}
📝 Title: ${concept.title}
📄 Full Concept Text:
${concept.text}
==========================================
        `);
    }

    /**
     * Generate and log summary report
     */
    private generateSummaryReport(concepts: Array<{id: string, moduleId: string, title: string, text: string}>): void {
        logger.warn(`
        
🎯 ========== CONCEPT EXTRACTION SUMMARY REPORT ==========
        `);
        
        // Group concepts by module
        const conceptsByModule = new Map<string, number>();
        for (const concept of concepts) {
            const count = conceptsByModule.get(concept.moduleId) || 0;
            conceptsByModule.set(concept.moduleId, count + 1);
        }
        
        // Log module-wise counts
        logger.warn(`📊 Concepts extracted per module:`);
        for (const [moduleId, count] of Array.from(conceptsByModule.entries()).sort()) {
            logger.warn(`   ${moduleId}: ${count} concepts`);
        }
        
        logger.warn(`\n📈 Total modules processed: ${conceptsByModule.size}`);
        logger.warn(`📈 Total concepts extracted: ${concepts.length}`);
        
        // Log concept titles summary
        logger.warn(`\n📋 All concept titles:`);
        for (const concept of concepts) {
            logger.warn(`   ${concept.id}: "${concept.title}"`);
        }
        
        logger.warn(`
========================================================
        `);
    }
}

/**
 * Step 3 Socratic Methodology Extraction Test
 * Shows exactly what "3.*" methodology steps are being extracted for all modules
 * Focuses on identifying missing nested content in methodology regex
 */
export class SocraticPhaseInvestigation {
    
    constructor() {
        // No API key needed for this investigation
    }

    /**
     * Main investigation execution function
     */
    public async runInvestigation(): Promise<void> {
        logger.warn("🔍 ========== STEP 3 SOCRATIC METHODOLOGY EXTRACTION ==========");
        
        try {
            // Extract modules and their methodology
            const curriculum = await this.loadCurriculum();
            logger.warn(`📊 Analyzing Step 3 methodology extraction across ${curriculum.modules.length} modules\n`);
            
            // Show Step 3 methodology for each module
            for (const [moduleIndex, module] of curriculum.modules.entries()) {
                this.displayModuleSocraticMethodology(module);
            }
            
            // Generate summary
            this.generateExtractionSummary(curriculum);
            
        } catch (error) {
            logger.error("❌ Step 3 methodology extraction analysis failed with error:", error);
        }
        
        logger.warn("🔍 ========== STEP 3 METHODOLOGY EXTRACTION COMPLETED ==========");
    }

    /**
     * Load curriculum from Modules.txt
     */
    private async loadCurriculum(): Promise<any> {
        logger.warn("📚 Loading curriculum from modules.txt...");
        
        try {
            const modulesResponse = await fetch('./Modules.txt');
            const modulesContent = await modulesResponse.text();
            const curriculum = parseModulesTxt(modulesContent);
            return curriculum;
        } catch (error) {
            throw new Error(`Failed to load curriculum: ${error}`);
        }
    }

    /**
     * Display Step 3 methodology extraction for a specific module
     * Shows exactly what content is captured by the methodology regex
     */
    private displayModuleSocraticMethodology(module: any): void {
        const displayModuleId = module.id.replace('Module', 'M').replace('_', '.');
        
        logger.warn(`🔬 MODULE ${displayModuleId}: ${module.title}`);
        
        // Find all methodology steps that start with "3."
        const socraticMethodologySteps = module.methodology.filter((step: any) => 
            step.title.trim().startsWith('3.')
        );
        
        logger.warn(`📋 Step 3 Methodology Found: ${socraticMethodologySteps.length} step(s)`);
        
        if (socraticMethodologySteps.length > 0) {
            socraticMethodologySteps.forEach((step: any, index: number) => {
                logger.warn(`
   ${step.title}
   Content: ${step.text}
                `);
            });
        } else {
            logger.warn(`   ⚠️  No methodology steps found starting with "3."`);
        }
        
        logger.warn(`============================================================\n`);
    }


    /**
     * Generate summary of Step 3 methodology extraction
     */
    private generateExtractionSummary(curriculum: any): void {
        logger.warn(`🎯 ========== STEP 3 METHODOLOGY EXTRACTION SUMMARY ==========`);
        
        let totalModules = curriculum.modules.length;
        let modulesWithSocraticSteps = 0;
        let totalSocraticSteps = 0;
        
        const moduleStats: Array<{id: string, title: string, stepCount: number}> = [];
        
        for (const module of curriculum.modules) {
            const displayModuleId = module.id.replace('Module', 'M').replace('_', '.');
            const socraticSteps = module.methodology.filter((step: any) => 
                step.title.trim().startsWith('3.')
            );
            
            if (socraticSteps.length > 0) {
                modulesWithSocraticSteps++;
                totalSocraticSteps += socraticSteps.length;
            }
            
            moduleStats.push({
                id: displayModuleId,
                title: module.title.substring(0, 40) + (module.title.length > 40 ? '...' : ''),
                stepCount: socraticSteps.length
            });
        }
        
        logger.warn(`📊 Extraction Statistics:`);
        logger.warn(`   Total modules analyzed: ${totalModules}`);
        logger.warn(`   Modules with Step 3 methodology: ${modulesWithSocraticSteps}`);
        logger.warn(`   Total Step 3 methodology steps found: ${totalSocraticSteps}`);
        
        logger.warn(`\n📋 Per-Module Breakdown:`);
        moduleStats.forEach(stat => {
            const status = stat.stepCount > 0 ? '✅' : '❌';
            logger.warn(`   ${status} ${stat.id}: ${stat.stepCount} step(s) - ${stat.title}`);
        });
        
        logger.warn(`
🔍 ANALYSIS NOTES:
   - Look for missing nested content (◦ bullet points, sub-numbered items)
   - Check if methodology content seems complete for Socratic teaching
   - Modules with 0 steps may need methodology sections added
   - Multiple steps per module suggest rich Socratic content structure
        `);
        
        logger.warn(`========================================================`);
    }
}

/**
 * Test Suite Runner - Controls which tests to run
 */
export class TestSuite {
    
    constructor() {}

    /**
     * Run the complete test suite based on configuration
     */
    public async runTestSuite(apiKey?: string): Promise<void> {
        if (!TEST_SUITE_CONFIG.enabled) {
            logger.warn("🔒 Test Suite is DISABLED. Set TEST_SUITE_CONFIG.enabled = true to run tests.");
            return;
        }

        logger.warn("🎬 ========== TEST SUITE EXECUTION STARTING ==========");
        
        try {
            // Run Concept Extraction Test
            if (TEST_SUITE_CONFIG.runConceptExtractionTest) {
                const conceptTest = new ConceptExtractionTest();
                await conceptTest.runTest();
            }

            // Run Socratic Phase Investigation
            if (TEST_SUITE_CONFIG.runSocraticPhaseInvestigation) {
                const socraticInvestigation = new SocraticPhaseInvestigation();
                await socraticInvestigation.runInvestigation();
            }

            // Run Archetype Comparison Test
            if (TEST_SUITE_CONFIG.runArchetypeTest) {
                if (!apiKey) {
                    logger.error("❌ API key required for Archetype Comparison Test");
                } else {
                    const archetypeTest = new ArchetypeComparisonTest(apiKey);
                    await archetypeTest.runTest();
                }
            }

            if (!TEST_SUITE_CONFIG.runConceptExtractionTest && !TEST_SUITE_CONFIG.runArchetypeTest && !TEST_SUITE_CONFIG.runSocraticPhaseInvestigation) {
                logger.warn("⚠️  No tests enabled in TEST_SUITE_CONFIG");
            }

        } catch (error) {
            logger.error("❌ Test Suite failed with error:", error);
        }
        
        logger.warn("🎬 ========== TEST SUITE EXECUTION COMPLETED ==========");
    }
}

// Export function to run the test suite
export async function runTestSuite(apiKey?: string): Promise<void> {
    const testSuite = new TestSuite();
    await testSuite.runTestSuite(apiKey);
}

// Legacy export function for backward compatibility (now runs full test suite)
export async function runArchetypeComparisonTest(apiKey: string): Promise<void> {
    await runTestSuite(apiKey);
} 